package safety.dev;

import android.content.Context;
import android.content.DialogInterface;
import android.os.CountDownTimer;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.FetchPlaceRequest;
import com.google.android.libraries.places.api.net.FetchPlaceResponse;
import com.google.android.libraries.places.api.net.PlacesClient;

import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import static androidx.constraintlayout.widget.Constraints.TAG;

public class Contacting extends AppCompatActivity {


    Double lat,lon;

   // String ApiKey = "AIzaSyDxzBQriUTlLvc_Cd4Dp4tbJkd8a0DBqKQ";   //coll156
    //String ApiKey = "AIzaSyA7zw60CBHiZPZARI9eowdZCZi_n6tp2S8"; //coll55
    String ApiKey = "AIzaSyBlPyv3sA7v8OEzipw0u8u9wdNhQo1Whds2"; //surya

    LocationResult locres;

    public void getLocation(LocationResult locationResult,Context context){
        locres = locationResult;
        final LocationResult loc = locationResult;
        lat = locationResult.getLastLocation().getLatitude();
        lon = locationResult.getLastLocation().getLongitude();
        Toast.makeText(context,"Lat:"+locationResult.getLastLocation().getLatitude()+"Lon:"+locationResult.getLastLocation().getLongitude(),Toast.LENGTH_LONG).show();
        Log.e(TAG, "Lat:"+locationResult.getLastLocation().getLatitude()+"Lon:"+locationResult.getLastLocation().getLongitude() );

    }



    private void getPlacePhonoDetails(Context context, final List<HashMap<String, String>> ParsedData) {

        Places.initialize(context, ApiKey);
        // Specify the fields to return.
        final List<Place.Field> placeFields = Arrays.asList(/*Place.Field.ID, Place.Field.NAME,*/ Place.Field.PHONE_NUMBER);

        final String[] placeIds = new String[ParsedData.size()];

        // Define a Place ID.
        String placeId = "ChIJj9uSb_CjNzoRSNDslyiH0ak";

       // final List<HashMap<String, String>> placePhoneDetails = new ArrayList<>();
        final HashMap<String , String> placePhoneDetails = new HashMap<>();


            // Construct a request object, passing the place ID and fields array.
            FetchPlaceRequest request = FetchPlaceRequest.newInstance(placeId, placeFields);
            PlacesClient placesClient = Places.createClient(context);
            placesClient.fetchPlace(request).addOnSuccessListener(new OnSuccessListener<FetchPlaceResponse>() {
                @Override
                public void onSuccess(FetchPlaceResponse response) {
                    //HashMap<String,String> hashMap = new HashMap<>();
                    Place place = response.getPlace();
                    // Log.i(TAG, "Place found: " + place.getName() + place.getPhoneNumber());
                    //hashMap.put("Name",place.getName());
                    //hashMap.put("Phone Number",place.getPhoneNumber());
                    //hashMap.put("Location",place.getAddress());
                    String pho = place.getPhoneNumber();

                    Log.i(TAG,pho);
                    // placePhoneDetails.add(hashMap);

                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception exception) {
                    if (exception instanceof ApiException) {
                        ApiException apiException = (ApiException) exception;
                        int statusCode = apiException.getStatusCode();
                        // Handle error with given status code.
                        Log.e(TAG, "Place not found: " + exception.getMessage());
                    }
                }
            });

        }


    public void send_sms(Context context) {

       final AlertDialog dialog = new AlertDialog.Builder(context)
                .setTitle("Sending Alerts.........")
               .setMessage("Click cancel to stop sending the alerts!")
               .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                   @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //TODO: Add positive button action code here
                        String num = "8328619345",txt = "I am in distress and my location is : https://www.google.com/maps/search/?api=1&query="+lat+","+lon;
                        SmsManager smsManager = SmsManager.getDefault();
                      //  smsManager.sendTextMessage(num,null,txt,null,null);
                        Log.i(TAG,"sms sent");
                    }
                })
                .setNegativeButton(android.R.string.no, null)
                .create();

        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            private static final int AUTO_DISMISS_MILLIS = 6000;
            @Override
            public void onShow(final DialogInterface dialog) {
                final Button defaultButton = ((AlertDialog) dialog).getButton(AlertDialog.BUTTON_NEGATIVE);
                final CharSequence negativeButtonText = defaultButton.getText();
                new CountDownTimer(AUTO_DISMISS_MILLIS, 100) {
                    @Override
                    public void onTick(long millisUntilFinished) {
                        defaultButton.setText(String.format(
                                Locale.getDefault(), "%s (%d)",
                                negativeButtonText,
                                TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) + 1 //add one so it never displays zero
                        ));
                    }
                    @Override
                    public void onFinish() {
                        if (((AlertDialog) dialog).isShowing()) {
                            dialog.dismiss();
                            String num = "8328619345", txt = "I am in distress and my location is : https://www.google.com/maps/search/?api=1&query=" + lat + "," + lon;
                            SmsManager smsManager = SmsManager.getDefault();
                            // smsManager.sendTextMessage(num,null,txt,null,null);
                            Log.i(TAG, "sms sent");
                        }
                    }
                }.start();
            }
        });

         dialog.show();



    }


    public void contactEmergencyContacts(Context context){
        getLocation(locres,context);
        Toast.makeText(context,"This is contactEmergencyContacts!",Toast.LENGTH_LONG).show();
        send_sms(context);
        // getPlaceDetails(context);      Uses the placeid to get the phone number**************************************
        //System.out.println("contacts called");

    }

    private void getNearPlaces(final Context context , String place) {
        int PROXIMITY_RADIUS = 10000;
        String nearbyPlace = place;
        StringBuilder googlePlacesUrl = new StringBuilder("https://maps.googleapis.com/maps/api/place/nearbysearch/json?");
        googlePlacesUrl.append("location=" + lat + "," + lon);
        googlePlacesUrl.append("&radius=" + PROXIMITY_RADIUS);
        googlePlacesUrl.append("&type=" + nearbyPlace);
        googlePlacesUrl.append("&sensor=true");
        googlePlacesUrl.append("&key=" + ApiKey);    //surya

        Log.i(TAG, "The url is: " + googlePlacesUrl.toString());

        String url = googlePlacesUrl.toString();
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.GET,  url,  null, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        Log.i(TAG,"Response from the Near by Places API: " + response.toString());
                        DataParser dataParser = new DataParser();
                        List<HashMap<String, String>> ParsedData = dataParser.parsing(response.toString());
                        Log.i(TAG,"The data received from the parsing method:"+ ParsedData);
                        getPlacePhonoDetails(context,ParsedData);

                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO: Handle error
                        Log.i(TAG,"NO Response: ");

                    }
                });
        MySingleton.getInstance(context).addToRequestQueue(jsonObjectRequest);

    }




    public void contactPolice(Context context) {
        Toast.makeText(context,"This is contactPolice!",Toast.LENGTH_LONG).show();
        getNearPlaces(context,"police");
        //send_sms(context);
    }

    public void contactHosipital(Context context) {
        Toast.makeText(context,"This is contactHosipital!",Toast.LENGTH_LONG).show();
        getNearPlaces(context,"hosipital");

    }

    public void contactFireDep(Context context) {
        Toast.makeText(context,"This is contactFireDep",Toast.LENGTH_LONG).show();
        getNearPlaces(context,"fire_station");

    }

    public void contactWomenSafety(Context context) {
        Toast.makeText(context,"This is contactWomenSafety!",Toast.LENGTH_LONG).show();

    }
}
